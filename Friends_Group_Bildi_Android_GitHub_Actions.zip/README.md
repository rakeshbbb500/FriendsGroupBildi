# Friend's Group BILDI — Android + GitHub Actions

This project wraps the Friend's Group BILDI web app in an Android WebView.

## Automatic APK build

Every push to `main`, every pull request, or a manual workflow run triggers GitHub Actions.

The workflow:
1. Checks out the repository.
2. Installs JDK 17.
3. Sets up Gradle 8.10.2.
4. Runs `gradle :app:assembleDebug`.
5. Uploads the generated APK as a GitHub Actions artifact.

Android's official documentation describes `assembleDebug` as the Gradle task for creating an installable debug APK. The APK is produced under `app/build/outputs/apk/`.

## GitHub steps

Create a repository, then upload the contents of this project to the repository root:

```text
FriendsGroupBildi/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/friendsgroup/bildi/MainActivity.kt
│       ├── res/layout/activity_main.xml
│       ├── res/values/styles.xml
│       └── assets/
│           ├── index.html
│           ├── manifest.json
│           ├── sw.js
│           └── logo.png
├── .github/workflows/build-apk.yml
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

Then go to:

**GitHub → Actions → Build Android APK → Run workflow**

Or simply push a commit to `main`.

## Download the APK

After the workflow completes:

**GitHub → Actions → Build Android APK → latest successful run → Artifacts → friends-group-bildi-debug-apk**

Download and unzip the artifact to get the `.apk`.

## Important

This workflow creates a **debug APK**. It is suitable for testing and sharing. A Play Store/release APK should be signed with a private release key. Never commit the keystore or passwords to the repository. Store signing credentials as GitHub Actions secrets.

## App data

The current app stores its data locally on the device using browser local storage inside the WebView. GitHub does not receive member records unless you deliberately add a backend or upload backup files.

Do not put real member records, passwords, or private backups into the GitHub repository.

## Future production release

For a production build, add:
- Release signing with GitHub Actions secrets
- Android Keystore
- Proper encrypted local database
- PDF file generation and Android share integration
- Optional cloud backup/login
- Versioned release APK/AAB
